import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import Navigation from "../components/Navigation";

export default function DashboardLayout() {
    const user = useAuthStore((state) => state.user);

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    return (
        <div className="min-h-screen bg-gray-50">
            <Navigation />
            <main className="py-6">
                <Outlet />
            </main>
        </div>
    );
}
