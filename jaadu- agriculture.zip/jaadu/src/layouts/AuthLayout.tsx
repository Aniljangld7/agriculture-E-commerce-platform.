import { Outlet, Navigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import { Sprout } from "lucide-react";

export default function AuthLayout() {
    const user = useAuthStore((state) => state.user);

    if (user) {
        return <Navigate to="/dashboard" replace />;
    }

    return (
        <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 flex flex-col">
            <nav className="bg-white shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16">
                        <div className="flex items-center">
                            <Sprout className="h-8 w-8 text-green-600" />
                            <span className="ml-2 text-xl font-bold text-gray-900">
                                AgroTrade
                            </span>
                        </div>
                    </div>
                </div>
            </nav>

            <div className="flex-1 flex items-center justify-center">
                <div className="max-w-md w-full px-4">
                    <Outlet />
                </div>
            </div>
        </div>
    );
}
