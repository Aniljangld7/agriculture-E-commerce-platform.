import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Cart from "./pages/Cart";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import BuyerDashboard from "./pages/dashboard/BuyerDashboard";
import FarmerDashboard from "./pages/dashboard/FarmerDashboard";
import AdminDashboard from "./pages/dashboard/AdminDashboard";
import { useAuthStore } from "./store/authStore";
import DashboardLayout from "./layouts/DashboardLayout";
import AuthLayout from "./layouts/AuthLayout";
import AddProduct from "./pages/dashboard/AddProduct";

function App() {
    const { user, initializeAuth } = useAuthStore();

    useEffect(() => {
        initializeAuth();
    }, [initializeAuth]);

    return (
        <Router>
            <Toaster position="top-right" />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/products" element={<Products />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/add-product" element={<AddProduct />} />

                <Route element={<AuthLayout />}>
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                </Route>

                <Route path="/dashboard" element={<DashboardLayout />}>
                    {user?.role === "buyer" && (
                        <Route index element={<BuyerDashboard />} />
                    )}
                    {user?.role === "farmer" && (
                        <Route index element={<FarmerDashboard />} />
                    )}
                    {user?.role === "admin" && (
                        <Route index element={<AdminDashboard />} />
                    )}
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
