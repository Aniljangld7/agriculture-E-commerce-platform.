export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          role: 'farmer' | 'buyer' | 'admin'
          full_name: string
          created_at: string | null
          phone: string | null
          avatar_url: string | null
          bio: string | null
          verification_status: string
          last_login: string | null
        }
        Insert: {
          id: string
          role: 'farmer' | 'buyer' | 'admin'
          full_name: string
          created_at?: string | null
          phone?: string | null
          avatar_url?: string | null
          bio?: string | null
          verification_status?: string
          last_login?: string | null
        }
        Update: {
          id?: string
          role?: 'farmer' | 'buyer' | 'admin'
          full_name?: string
          created_at?: string | null
          phone?: string | null
          avatar_url?: string | null
          bio?: string | null
          verification_status?: string
          last_login?: string | null
        }
      }
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          description: string | null
          parent_id: string | null
          created_at: string | null
        }
        Insert: {
          id?: string
          name: string
          slug: string
          description?: string | null
          parent_id?: string | null
          created_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          description?: string | null
          parent_id?: string | null
          created_at?: string | null
        }
      }
      products: {
        Row: {
          id: string
          name: string
          description: string | null
          price: number
          category: string
          stock: number
          image_url: string | null
          farmer_id: string | null
          created_at: string | null
          brand: string | null
          organic: boolean
          certification: string | null
          harvest_date: string | null
          expiry_date: string | null
          category_id: string | null
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          price: number
          category: string
          stock?: number
          image_url?: string | null
          farmer_id?: string | null
          created_at?: string | null
          brand?: string | null
          organic?: boolean
          certification?: string | null
          harvest_date?: string | null
          expiry_date?: string | null
          category_id?: string | null
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          price?: number
          category?: string
          stock?: number
          image_url?: string | null
          farmer_id?: string | null
          created_at?: string | null
          brand?: string | null
          organic?: boolean
          certification?: string | null
          harvest_date?: string | null
          expiry_date?: string | null
          category_id?: string | null
        }
      }
      product_variants: {
        Row: {
          id: string
          product_id: string
          sku: string
          price: number
          stock: number
          weight: number | null
          unit: string
          created_at: string | null
        }
        Insert: {
          id?: string
          product_id: string
          sku: string
          price: number
          stock?: number
          weight?: number | null
          unit: string
          created_at?: string | null
        }
        Update: {
          id?: string
          product_id?: string
          sku?: string
          price?: number
          stock?: number
          weight?: number | null
          unit?: string
          created_at?: string | null
        }
      }
      product_images: {
        Row: {
          id: string
          product_id: string
          url: string
          alt_text: string | null
          is_primary: boolean
          created_at: string | null
        }
        Insert: {
          id?: string
          product_id: string
          url: string
          alt_text?: string | null
          is_primary?: boolean
          created_at?: string | null
        }
        Update: {
          id?: string
          product_id?: string
          url?: string
          alt_text?: string | null
          is_primary?: boolean
          created_at?: string | null
        }
      }
      reviews: {
        Row: {
          id: string
          product_id: string
          user_id: string
          rating: number
          comment: string | null
          created_at: string | null
        }
        Insert: {
          id?: string
          product_id: string
          user_id: string
          rating: number
          comment?: string | null
          created_at?: string | null
        }
        Update: {
          id?: string
          product_id?: string
          user_id?: string
          rating?: number
          comment?: string | null
          created_at?: string | null
        }
      }
      shipping_addresses: {
        Row: {
          id: string
          user_id: string
          full_name: string
          address_line1: string
          address_line2: string | null
          city: string
          state: string
          postal_code: string
          country: string
          phone: string
          is_default: boolean
          created_at: string | null
        }
        Insert: {
          id?: string
          user_id: string
          full_name: string
          address_line1: string
          address_line2?: string | null
          city: string
          state: string
          postal_code: string
          country: string
          phone: string
          is_default?: boolean
          created_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string
          address_line1?: string
          address_line2?: string | null
          city?: string
          state?: string
          postal_code?: string
          country?: string
          phone?: string
          is_default?: boolean
          created_at?: string | null
        }
      }
      orders: {
        Row: {
          id: string
          buyer_id: string | null
          farmer_id: string | null
          product_id: string | null
          quantity: number
          total_amount: number
          status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled'
          payment_status: 'pending' | 'completed' | 'failed'
          created_at: string | null
          shipping_address_id: string | null
          tracking_number: string | null
          estimated_delivery_date: string | null
          actual_delivery_date: string | null
          shipping_method: string | null
          shipping_cost: number
        }
        Insert: {
          id?: string
          buyer_id?: string | null
          farmer_id?: string | null
          product_id?: string | null
          quantity: number
          total_amount: number
          status?: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled'
          payment_status?: 'pending' | 'completed' | 'failed'
          created_at?: string | null
          shipping_address_id?: string | null
          tracking_number?: string | null
          estimated_delivery_date?: string | null
          actual_delivery_date?: string | null
          shipping_method?: string | null
          shipping_cost?: number
        }
        Update: {
          id?: string
          buyer_id?: string | null
          farmer_id?: string | null
          product_id?: string | null
          quantity?: number
          total_amount?: number
          status?: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled'
          payment_status?: 'pending' | 'completed' | 'failed'
          created_at?: string | null
          shipping_address_id?: string | null
          tracking_number?: string | null
          estimated_delivery_date?: string | null
          actual_delivery_date?: string | null
          shipping_method?: string | null
          shipping_cost?: number
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      user_role: 'farmer' | 'buyer' | 'admin'
      order_status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled'
      payment_status: 'pending' | 'completed' | 'failed'
    }
  }
}