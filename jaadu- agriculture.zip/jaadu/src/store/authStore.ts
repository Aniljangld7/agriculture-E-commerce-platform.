import { create } from "zustand";
import { User } from "../types";
import { supabase } from "../lib/supabase";

interface AuthState {
    user: User | null;
    loading: boolean;
    signIn: (email: string, password: string) => Promise<void>;
    signUp: (
        email: string,
        password: string,
        role: "farmer" | "buyer",
        fullName: string
    ) => Promise<void>;
    signOut: () => Promise<void>;
    initializeAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
    user: null,
    loading: true,
    initializeAuth: async () => {
        try {
            const {
                data: { session },
            } = await supabase.auth.getSession();
            if (session?.user) {
                const { data: profile, error } = await supabase
                    .from("profiles")
                    .select("*")
                    .eq("id", session.user.id)
                    .maybeSingle(); // Use maybeSingle instead of single to handle missing profiles gracefully

                if (error) {
                    console.error("Error fetching profile:", error);
                    set({ user: null, loading: false });
                    return;
                }

                if (profile) {
                    set({
                        user: {
                            id: session.user.id,
                            email: session.user.email!,
                            role: profile.role,
                            full_name: profile.full_name,
                            created_at:
                                profile.created_at || new Date().toISOString(),
                        },
                        loading: false,
                    });
                } else {
                    // Handle case where profile doesn't exist
                    console.warn("No profile found for user:", session.user.id);
                    set({ user: null, loading: false });
                }
            } else {
                set({ user: null, loading: false });
            }
        } catch (error) {
            console.error("Error initializing auth:", error);
            set({ user: null, loading: false });
        }
    },
    signIn: async (email, password) => {
        const {
            data: { session },
            error: signInError,
        } = await supabase.auth.signInWithPassword({
            email,
            password,
        });

        if (signInError) throw signInError;

        if (session?.user) {
            const { data: profile, error: profileError } = await supabase
                .from("profiles")
                .select("*")
                .eq("id", session.user.id)
                .maybeSingle(); // Use maybeSingle here as well

            if (profileError) {
                console.error("Error fetching profile:", profileError);
                throw profileError;
            }

            if (profile) {
                set({
                    user: {
                        id: session.user.id,
                        email: session.user.email!,
                        role: profile.role,
                        full_name: profile.full_name,
                        created_at:
                            profile.created_at || new Date().toISOString(),
                    },
                });
            } else {
                throw new Error("Profile not found");
            }
        }
    },
    signUp: async (email, password, role, fullName) => {
        const {
            data: { user },
            error: signUpError,
        } = await supabase.auth.signUp({
            email,
            password,
        });

        if (signUpError) throw signUpError;
        if (!user) throw new Error("User creation failed");

        const { error: profileError } = await supabase.from("profiles").insert([
            {
                id: user.id,
                role,
                full_name: fullName,
            },
        ]);

        if (profileError) {
            // If profile creation fails, delete the auth user to maintain consistency
            await supabase.auth.admin.deleteUser(user.id);
            throw profileError;
        }

        set({
            user: {
                id: user.id,
                email: user.email!,
                role,
                full_name: fullName,
                created_at: new Date().toISOString(),
            },
        });
    },
    signOut: async () => {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        set({ user: null });
    },
}));
