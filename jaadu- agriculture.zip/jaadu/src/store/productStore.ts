import { create } from "zustand";
import { supabase } from "../lib/supabase";
import type { Product } from "../types";

interface ProductState {
    products: Product[];
    loading: boolean;
    error: string | null;
    fetchProducts: () => Promise<void>;
    addProduct: (product: Omit<Product, "id" | "created_at">) => Promise<void>;
    updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
    deleteProduct: (id: string) => Promise<void>;
}

export const useProductStore = create<ProductState>((set, get) => ({
    products: [],
    loading: false,
    error: null,
    fetchProducts: async () => {
        set({ loading: true, error: null });
        try {
            const { data, error } = await supabase
                .from("products")
                .select("*")
                .order("created_at", { ascending: false });

            if (error) throw error;
            set({ products: data || [], loading: false });
        } catch (error) {
            set({ error: "Failed to fetch products", loading: false });
        }
    },
    addProduct: async (product) => {
        try {
            const { data, error } = await supabase
                .from("products")
                .insert([product])
                .select()
                .single();

            if (error) throw error;
            set({ products: [data, ...get().products] });
        } catch (error) {
            set({ error: "Failed to add product" });
        }
    },
    updateProduct: async (id, updates) => {
        try {
            const { data, error } = await supabase
                .from("products")
                .update(updates)
                .eq("id", id)
                .select()
                .single();

            if (error) throw error;
            set({
                products: get().products.map((p) =>
                    p.id === id ? { ...p, ...data } : p
                ),
            });
        } catch (error) {
            set({ error: "Failed to update product" });
        }
    },
    deleteProduct: async (id) => {
        try {
            const { error } = await supabase
                .from("products")
                .delete()
                .eq("id", id);
            if (error) throw error;
            set({ products: get().products.filter((p) => p.id !== id) });
        } catch (error) {
            set({ error: "Failed to delete product" });
        }
    },
}));
