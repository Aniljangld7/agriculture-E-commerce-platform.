import { create } from "zustand";
import { supabase } from "../lib/supabase";
import type { Order } from "../types";

interface OrderState {
    orders: Order[];
    loading: boolean;
    error: string | null;
    fetchOrders: (userid: string, type: "buyer" | "farmer") => Promise<void>;
    createOrder: (order: Omit<Order, "id" | "created_at">) => Promise<void>;
    updateOrderStatus: (id: string, status: Order["status"]) => Promise<void>;
}

export const useOrderStore = create<OrderState>((set, get) => ({
    orders: [],
    loading: false,
    error: null,
    fetchOrders: async (userid: string, type: "buyer" | "farmer") => {
        set({ loading: true, error: null });
        try {
            const { data, error } = await supabase
                .from("orders")
                .select("*, products(*)")
                .eq(type === "buyer" ? "buyer_id" : "farmer_id", userid)
                .order("created_at", { ascending: false });

            if (error) throw error;
            set({ orders: data || [], loading: false });
        } catch (error) {
            set({ error: "Failed to fetch orders", loading: false });
        }
    },
    createOrder: async (order) => {
        try {
            const { data, error } = await supabase
                .from("orders")
                .insert([order])
                .select()
                .single();

            if (error) throw error;
            set({ orders: [data, ...get().orders] });
        } catch (error) {
            set({ error: "Failed to create order" });
        }
    },
    updateOrderStatus: async (id, status) => {
        try {
            const { data, error } = await supabase
                .from("orders")
                .update({ status })
                .eq("id", id)
                .select()
                .single();

            if (error) throw error;
            set({
                orders: get().orders.map((o) =>
                    o.id === id ? { ...o, ...data } : o
                ),
            });
        } catch (error) {
            set({ error: "Failed to update order status" });
        }
    },
}));
