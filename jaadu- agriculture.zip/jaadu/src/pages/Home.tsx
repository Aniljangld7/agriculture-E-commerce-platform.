import React from 'react';
import { Link } from 'react-router-dom';
import { Sprout } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Sprout className="h-8 w-8 text-green-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">AgroTrade</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="px-4 py-2 rounded-md text-green-600 hover:text-green-700"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
              >
                Register
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
            <span className="block">Connect Directly with</span>
            <span className="block text-green-600">Farmers & Buyers</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Join our agricultural marketplace where farmers and buyers come together.
            Trade fresh produce directly, eliminate middlemen, and support local farming.
          </p>
          <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
            <div className="rounded-md shadow">
              <Link
                to="/register?role=farmer"
                className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700 md:py-4 md:text-lg md:px-10"
              >
                Join as Farmer
              </Link>
            </div>
            <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3">
              <Link
                to="/register?role=buyer"
                className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-green-600 bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10"
              >
                Join as Buyer
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-green-600 mb-4">
              <Sprout className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Direct Trading</h3>
            <p className="mt-2 text-gray-500">
              Connect directly with farmers or buyers without intermediaries.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-green-600 mb-4">
              <Sprout className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Secure Payments</h3>
            <p className="mt-2 text-gray-500">
              Safe and secure payment processing for all transactions.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-green-600 mb-4">
              <Sprout className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Quality Assurance</h3>
            <p className="mt-2 text-gray-500">
              All products are verified for quality and authenticity.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}