import React from 'react';
import { useAuthStore } from '../../store/authStore';

export default function AdminDashboard() {
  const user = useAuthStore((state) => state.user);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">User Management</h2>
          {/* User management will be implemented here */}
          <p className="text-gray-600">No pending approvals</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Product Moderation</h2>
          {/* Product moderation will be implemented here */}
          <p className="text-gray-600">No products to moderate</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">System Analytics</h2>
          {/* System analytics will be implemented here */}
          <p className="text-gray-600">Loading analytics...</p>
        </div>
      </div>
    </div>
  );
}