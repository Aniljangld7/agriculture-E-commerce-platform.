import { useState } from "react";
import { Input } from "../../components/ui/Input";
import { Textarea } from "../../components/ui/Textarea";
import { Button } from "../../components/ui/Button";
import { useProductStore } from "../../store/productStore";
import { useAuthStore } from "../../store/authStore";
import { redirect } from "react-router-dom";

export default function AddProduct() {
    const user = useAuthStore((state) => state.user);

    const [form, setForm] = useState({
        name: "",
        description: "",
        price: 0,
        category: "",
        stock: 0,
        image_url: "",
    });

    const addProduct = useProductStore((state) => state.addProduct);

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]:
                name === "price" || name === "stock" ? Number(value) : value,
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (user) {
            addProduct({
                category: form.category,
                description: form.description,
                image_url: form.image_url,
                name: form.name,
                price: form.price,
                stock: form.stock,
                farmer_id: user?.id,
            });
            redirect("/dashboard");
            console.log("Submitting Product", form);
        } else {
            console.error("User not found");
        }
        // Replace with your submission logic (e.g. API call)
    };

    return (
        <div className="max-w-xl mx-auto p-8 bg-green-50 shadow-md rounded-2xl mt-10">
            <h1 className="text-3xl font-bold text-green-700 mb-6 text-center">
                Add New Product
            </h1>
            <form onSubmit={handleSubmit} className="space-y-5">
                <Input
                    name="name"
                    placeholder="Product Name"
                    value={form.name}
                    onChange={handleChange}
                    required
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Textarea
                    name="description"
                    placeholder="Description"
                    value={form.description}
                    onChange={handleChange}
                    required
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Input
                    name="price"
                    type="number"
                    placeholder="Price"
                    value={form.price}
                    onChange={handleChange}
                    required
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Input
                    name="category"
                    placeholder="Category"
                    value={form.category}
                    onChange={handleChange}
                    required
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Input
                    name="stock"
                    type="number"
                    placeholder="Stock"
                    value={form.stock}
                    onChange={handleChange}
                    required
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Input
                    name="image_url"
                    placeholder="Image URL"
                    value={form.image_url}
                    onChange={handleChange}
                    className="border-green-400 focus:ring-green-500 focus:border-green-500"
                />
                <Button
                    type="submit"
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 rounded-xl"
                >
                    Add Product
                </Button>
            </form>
        </div>
    );
}
