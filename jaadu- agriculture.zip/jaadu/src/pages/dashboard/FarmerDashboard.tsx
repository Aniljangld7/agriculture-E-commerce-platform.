import React from "react";
import { useAuthStore } from "../../store/authStore";
import { useOrderStore } from "../../store/orderStore";
import { Link } from "react-router-dom";

export default function FarmerDashboard() {
    const user = useAuthStore((state) => state.user);
    const orders = useOrderStore((state) => state.orders);
    const fetchOrders = useOrderStore((state) => state.fetchOrders);

    React.useEffect(() => {
        if (user) {
            fetchOrders(user.id, "farmer");
        }
    }, [user, fetchOrders]);

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-2xl font-bold mb-6">
                Welcome, {user?.full_name}
                <Link
                    className="bg-green-400 px-4 py-2 rounded border ml-4"
                    to="/add-product"
                >
                    Add Products
                </Link>
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-lg font-semibold mb-4">
                        Orders Received
                    </h2>
                    {orders.map((order) => {
                        return (
                            <div
                                key={order.id}
                                className="border-b border-gray-200 py-2"
                            >
                                <h3 className="text-md font-semibold">
                                    Order ID: {order.id}
                                </h3>
                                <p className="text-gray-600">
                                    Total: ${order.total_amount.toFixed(2)}
                                </p>
                                <p className="text-gray-600">
                                    Status: {order.status}
                                </p>
                                <p className="text-gray-600">
                                    Date:{" "}
                                    {new Date(
                                        order.created_at
                                    ).toLocaleDateString()}
                                </p>
                            </div>
                        );
                    })}

                    {/* Orders received will be implemented here */}
                    <p className="text-gray-600">No orders received</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-lg font-semibold mb-4">My Products</h2>
                    {/* Products list will be implemented here */}
                    <p className="text-gray-600">No products listed</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-lg font-semibold mb-4">
                        Sales Analytics
                    </h2>
                    {/* Analytics will be implemented here */}
                    <p className="text-gray-600">No sales data available</p>
                </div>
            </div>
        </div>
    );
}
