import React, { useEffect, useState } from "react";
import { useProductStore } from "../store/productStore";
import { useCartStore } from "../store/cartStore";
import { useAuthStore } from "../store/authStore";
import { ShoppingCart, Filter, Search } from "lucide-react";
import toast from "react-hot-toast";
import Navigation from "../components/Navigation";

export default function Products() {
    const { products, loading, fetchProducts } = useProductStore();
    const { addItem } = useCartStore();
    const { user } = useAuthStore();
    const [selectedCategory, setSelectedCategory] = useState<string>("all");
    const [searchQuery, setSearchQuery] = useState("");
    const [priceRange, setPriceRange] = useState<{ min: number; max: number }>({
        min: 0,
        max: 1000,
    });
    const [sortBy, setSortBy] = useState<
        "price-asc" | "price-desc" | "name-asc" | "name-desc"
    >("name-asc");

    useEffect(() => {
        fetchProducts();
    }, [fetchProducts]);

    const categories = ["all", ...new Set(products.map((p) => p.category))];

    const filteredProducts = products
        .filter((product) => {
            const matchesCategory =
                selectedCategory === "all" ||
                product.category === selectedCategory;
            const matchesSearch =
                product.name
                    .toLowerCase()
                    .includes(searchQuery.toLowerCase()) ||
                product.description
                    ?.toLowerCase()
                    .includes(searchQuery.toLowerCase());
            const matchesPrice =
                product.price >= priceRange.min &&
                product.price <= priceRange.max;
            return matchesCategory && matchesSearch && matchesPrice;
        })
        .sort((a, b) => {
            switch (sortBy) {
                case "price-asc":
                    return a.price - b.price;
                case "price-desc":
                    return b.price - a.price;
                case "name-asc":
                    return a.name.localeCompare(b.name);
                case "name-desc":
                    return b.name.localeCompare(a.name);
                default:
                    return 0;
            }
        });

    const handleAddToCart = (product: (typeof products)[0]) => {
        if (!user) {
            toast.error("Please login to add items to cart");
            return;
        }
        if (user.role !== "buyer") {
            toast.error("Only buyers can add items to cart");
            return;
        }
        addItem(product, 1);
        toast.success("Added to cart");
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center min-h-screen">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500"></div>
            </div>
        );
    }

    return (
        <>
            <Navigation />
            <div className="container mx-auto px-4 py-8">
                <div className="mb-8 bg-white p-6 rounded-lg shadow-md">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Search
                            </label>
                            <div className="relative">
                                <Search
                                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                                    size={20}
                                />
                                <input
                                    type="text"
                                    placeholder="Search products..."
                                    className="pl-10 w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    value={searchQuery}
                                    onChange={(e) =>
                                        setSearchQuery(e.target.value)
                                    }
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Category
                            </label>
                            <select
                                value={selectedCategory}
                                onChange={(e) =>
                                    setSelectedCategory(e.target.value)
                                }
                                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                            >
                                {categories.map((category) => (
                                    <option key={category} value={category}>
                                        {category.charAt(0).toUpperCase() +
                                            category.slice(1)}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Price Range
                            </label>
                            <div className="flex items-center space-x-2">
                                <input
                                    type="number"
                                    placeholder="Min"
                                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    value={priceRange.min}
                                    onChange={(e) =>
                                        setPriceRange((prev) => ({
                                            ...prev,
                                            min: Number(e.target.value),
                                        }))
                                    }
                                />
                                <span>-</span>
                                <input
                                    type="number"
                                    placeholder="Max"
                                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    value={priceRange.max}
                                    onChange={(e) =>
                                        setPriceRange((prev) => ({
                                            ...prev,
                                            max: Number(e.target.value),
                                        }))
                                    }
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Sort By
                            </label>
                            <select
                                value={sortBy}
                                onChange={(e) =>
                                    setSortBy(e.target.value as typeof sortBy)
                                }
                                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                            >
                                <option value="name-asc">Name (A-Z)</option>
                                <option value="name-desc">Name (Z-A)</option>
                                <option value="price-asc">
                                    Price (Low to High)
                                </option>
                                <option value="price-desc">
                                    Price (High to Low)
                                </option>
                            </select>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredProducts.map((product) => (
                        <div
                            key={product.id}
                            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
                        >
                            {product.image_url && (
                                <img
                                    src={product.image_url}
                                    alt={product.name}
                                    className="w-full h-48 object-cover hover:opacity-90 transition-opacity duration-300"
                                />
                            )}
                            <div className="p-4">
                                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                                    {product.name}
                                </h3>
                                <p className="text-gray-600 text-sm mb-3">
                                    {product.description}
                                </p>
                                <div className="flex items-center justify-between mb-3">
                                    <span className="text-xl font-bold text-green-600">
                                        &#8377;{product.price.toFixed(2)}
                                    </span>
                                    <span className="text-sm text-gray-500">
                                        Stock: {product.stock}
                                    </span>
                                </div>
                                <div className="text-sm text-gray-500 mb-4">
                                    Category:{" "}
                                    {product.category.charAt(0).toUpperCase() +
                                        product.category.slice(1)}
                                </div>
                                <button
                                    onClick={() => handleAddToCart(product)}
                                    disabled={product.stock === 0}
                                    className={`w-full flex items-center justify-center px-4 py-2 rounded-md ${
                                        product.stock === 0
                                            ? "bg-gray-300 cursor-not-allowed"
                                            : "bg-green-600 hover:bg-green-700"
                                    } text-white transition-colors duration-300`}
                                >
                                    <ShoppingCart className="w-5 h-5 mr-2" />
                                    {product.stock === 0
                                        ? "Out of Stock"
                                        : "Add to Cart"}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {filteredProducts.length === 0 && (
                    <div className="text-center py-12">
                        <Filter className="mx-auto h-12 w-12 text-gray-400" />
                        <h3 className="mt-4 text-lg font-medium text-gray-900">
                            No products found
                        </h3>
                        <p className="mt-2 text-gray-500">
                            Try adjusting your search or filter criteria
                        </p>
                    </div>
                )}
            </div>
        </>
    );
}
