/*
  # Enhanced E-commerce Platform Schema

  1. New Tables
    - categories
      - id (uuid)
      - name (text)
      - slug (text)
      - description (text)
      - parent_id (uuid, self-referential)
      - created_at (timestamp)

    - product_variants
      - id (uuid)
      - product_id (uuid)
      - sku (text)
      - price (numeric)
      - stock (integer)
      - weight (numeric)
      - unit (text)
      - created_at (timestamp)

    - product_images
      - id (uuid)
      - product_id (uuid)
      - url (text)
      - alt_text (text)
      - is_primary (boolean)
      - created_at (timestamp)

    - reviews
      - id (uuid)
      - product_id (uuid)
      - user_id (uuid)
      - rating (integer)
      - comment (text)
      - created_at (timestamp)

    - shipping_addresses
      - id (uuid)
      - user_id (uuid)
      - full_name (text)
      - address_line1 (text)
      - address_line2 (text)
      - city (text)
      - state (text)
      - postal_code (text)
      - country (text)
      - phone (text)
      - is_default (boolean)
      - created_at (timestamp)

  2. Enhancements to Existing Tables
    - Add fields to products table
    - Add fields to orders table
    - Add fields to profiles table

  3. Security
    - Enable RLS on all new tables
    - Add appropriate policies
*/

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  parent_id uuid REFERENCES categories(id),
  created_at timestamptz DEFAULT now()
);

-- Create product_variants table
CREATE TABLE product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  sku text NOT NULL UNIQUE,
  price numeric NOT NULL CHECK (price > 0),
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  weight numeric,
  unit text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create product_images table
CREATE TABLE product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  url text NOT NULL,
  alt_text text,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(product_id, user_id)
);

-- Create shipping_addresses table
CREATE TABLE shipping_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  phone text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Add fields to products table
ALTER TABLE products
ADD COLUMN IF NOT EXISTS brand text,
ADD COLUMN IF NOT EXISTS organic boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS certification text,
ADD COLUMN IF NOT EXISTS harvest_date date,
ADD COLUMN IF NOT EXISTS expiry_date date,
ADD COLUMN IF NOT EXISTS category_id uuid REFERENCES categories(id);

-- Add fields to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS shipping_address_id uuid REFERENCES shipping_addresses(id),
ADD COLUMN IF NOT EXISTS tracking_number text,
ADD COLUMN IF NOT EXISTS estimated_delivery_date date,
ADD COLUMN IF NOT EXISTS actual_delivery_date date,
ADD COLUMN IF NOT EXISTS shipping_method text,
ADD COLUMN IF NOT EXISTS shipping_cost numeric DEFAULT 0;

-- Add fields to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS phone text,
ADD COLUMN IF NOT EXISTS avatar_url text,
ADD COLUMN IF NOT EXISTS bio text,
ADD COLUMN IF NOT EXISTS verification_status text DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS last_login timestamptz;

-- Enable RLS on new tables
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipping_addresses ENABLE ROW LEVEL SECURITY;

-- Categories policies
CREATE POLICY "Categories are viewable by everyone"
  ON categories FOR SELECT
  USING (true);

CREATE POLICY "Admin can manage categories"
  ON categories FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Product variants policies
CREATE POLICY "Product variants are viewable by everyone"
  ON product_variants FOR SELECT
  USING (true);

CREATE POLICY "Farmers can manage their product variants"
  ON product_variants FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_variants.product_id
      AND products.farmer_id = auth.uid()
    )
  );

-- Product images policies
CREATE POLICY "Product images are viewable by everyone"
  ON product_images FOR SELECT
  USING (true);

CREATE POLICY "Farmers can manage their product images"
  ON product_images FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_images.product_id
      AND products.farmer_id = auth.uid()
    )
  );

-- Reviews policies
CREATE POLICY "Reviews are viewable by everyone"
  ON reviews FOR SELECT
  USING (true);

CREATE POLICY "Buyers can create reviews"
  ON reviews FOR INSERT
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'buyer'
    )
  );

CREATE POLICY "Users can update their own reviews"
  ON reviews FOR UPDATE
  USING (auth.uid() = user_id);

-- Shipping addresses policies
CREATE POLICY "Users can view their own shipping addresses"
  ON shipping_addresses FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own shipping addresses"
  ON shipping_addresses FOR ALL
  USING (auth.uid() = user_id);

-- Insert sample categories
INSERT INTO categories (name, slug, description) VALUES
  ('Vegetables', 'vegetables', 'Fresh vegetables directly from farms'),
  ('Fruits', 'fruits', 'Fresh seasonal fruits'),
  ('Grains', 'grains', 'Various types of grains and cereals'),
  ('Dairy', 'dairy', 'Fresh dairy products'),
  ('Herbs', 'herbs', 'Fresh and dried herbs'),
  ('Organic', 'organic', 'Certified organic products')
ON CONFLICT (slug) DO NOTHING;