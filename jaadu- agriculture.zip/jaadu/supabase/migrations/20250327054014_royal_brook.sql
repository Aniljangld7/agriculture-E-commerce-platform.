/*
  # Enhanced Authentication Policies and Additional Data

  1. Policies
    - Add policies for authentication
    - Update existing policies for better access control
    - Add policies for order management
  
  2. Additional Data
    - Add more test products
    - Add test orders
*/

-- Additional policies for profiles
CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Additional policies for products
CREATE POLICY "Admin can manage all products"
  ON products FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Additional policies for orders
CREATE POLICY "Admin can view all orders"
  ON orders FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

CREATE POLICY "Farmers can update order status"
  ON orders FOR UPDATE
  USING (
    auth.uid() = farmer_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'farmer'
    )
  )
  WITH CHECK (
    status IN ('shipped', 'delivered')
  );

-- Add more test products
INSERT INTO public.products (
  name,
  description,
  price,
  category,
  stock,
  image_url,
  farmer_id
)
VALUES 
  (
    'Organic Quinoa',
    'Premium quality organic quinoa, rich in protein and nutrients',
    6.99,
    'grains',
    120,
    'https://images.unsplash.com/photo-1586201375761-83865001e31c',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Avocados',
    'Creamy and ripe avocados, perfect for any meal',
    3.49,
    'fruits',
    80,
    'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Organic Chia Seeds',
    'Nutrient-rich chia seeds for healthy eating',
    5.99,
    'grains',
    150,
    'https://images.unsplash.com/photo-1514537099923-4c0fc7c73161',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Bell Peppers',
    'Colorful organic bell peppers',
    2.99,
    'vegetables',
    100,
    'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83',
    '00000000-0000-0000-0000-000000000001'
  )
ON CONFLICT DO NOTHING;