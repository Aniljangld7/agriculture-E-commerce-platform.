/*
  # Initial Schema Setup for AgroTrade Platform

  1. New Tables
    - profiles
      - id (uuid, references auth.users)
      - role (enum: farmer, buyer, admin)
      - full_name (text)
      - created_at (timestamp)
    
    - products
      - id (uuid)
      - name (text)
      - description (text)
      - price (numeric)
      - category (text)
      - stock (integer)
      - image_url (text)
      - farmer_id (uuid, references profiles)
      - created_at (timestamp)
    
    - orders
      - id (uuid)
      - buyer_id (uuid, references profiles)
      - farmer_id (uuid, references profiles)
      - product_id (uuid, references products)
      - quantity (integer)
      - total_amount (numeric)
      - status (enum)
      - payment_status (enum)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for each table based on user roles
*/

-- Create enum types
CREATE TYPE user_role AS ENUM ('farmer', 'buyer', 'admin');
CREATE TYPE order_status AS ENUM ('pending', 'paid', 'shipped', 'delivered', 'cancelled');
CREATE TYPE payment_status AS ENUM ('pending', 'completed', 'failed');

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  role user_role NOT NULL,
  full_name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create products table
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price > 0),
  category text NOT NULL,
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_url text,
  farmer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  farmer_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  total_amount numeric NOT NULL CHECK (total_amount > 0),
  status order_status DEFAULT 'pending',
  payment_status payment_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Products policies
CREATE POLICY "Products are viewable by everyone"
  ON products FOR SELECT
  USING (true);

CREATE POLICY "Farmers can insert their own products"
  ON products FOR INSERT
  WITH CHECK (
    auth.uid() = farmer_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'farmer'
    )
  );

CREATE POLICY "Farmers can update their own products"
  ON products FOR UPDATE
  USING (
    auth.uid() = farmer_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'farmer'
    )
  );

-- Orders policies
CREATE POLICY "Users can view their own orders"
  ON orders FOR SELECT
  USING (
    auth.uid() = buyer_id
    OR auth.uid() = farmer_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

CREATE POLICY "Buyers can create orders"
  ON orders FOR INSERT
  WITH CHECK (
    auth.uid() = buyer_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'buyer'
    )
  );

CREATE POLICY "Users can update their own orders"
  ON orders FOR UPDATE
  USING (
    auth.uid() = buyer_id
    OR auth.uid() = farmer_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );