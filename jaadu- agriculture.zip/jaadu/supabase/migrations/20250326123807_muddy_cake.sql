/*
  # Create test users and products

  This migration adds test data for development and testing purposes.
*/

-- Insert test users
INSERT INTO auth.users (id, email)
VALUES 
  ('00000000-0000-0000-0000-000000000001', 'farmer@test.com'),
  ('00000000-0000-0000-0000-000000000002', 'buyer@test.com')
ON CONFLICT (id) DO NOTHING;

-- Insert test profiles
INSERT INTO public.profiles (id, role, full_name)
VALUES 
  ('00000000-0000-0000-0000-000000000001', 'farmer', 'Test Farmer'),
  ('00000000-0000-0000-0000-000000000002', 'buyer', 'Test Buyer')
ON CONFLICT (id) DO NOTHING;

-- Insert test products
INSERT INTO public.products (
  name,
  description,
  price,
  category,
  stock,
  image_url,
  farmer_id
)
VALUES 
  (
    'Fresh Tomatoes',
    'Locally grown organic tomatoes',
    2.99,
    'vegetables',
    100,
    'https://images.unsplash.com/photo-1546470427-1ec6e8a4bdc8',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Organic Apples',
    'Sweet and crispy apples from our orchard',
    1.99,
    'fruits',
    150,
    'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Carrots',
    'Organic carrots harvested daily',
    1.49,
    'vegetables',
    200,
    'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37',
    '00000000-0000-0000-0000-000000000001'
  )
ON CONFLICT DO NOTHING;