/*
  # Add more test products and categories
  
  This migration adds a variety of products across different categories
  to provide a better testing and demonstration experience.
*/

INSERT INTO public.products (
  name,
  description,
  price,
  category,
  stock,
  image_url,
  farmer_id
)
VALUES 
  (
    'Organic Strawberries',
    'Sweet and juicy strawberries, perfect for desserts',
    4.99,
    'fruits',
    75,
    'https://images.unsplash.com/photo-1464965911861-746a04b4bca6',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Spinach',
    'Nutrient-rich spinach leaves, locally grown',
    2.49,
    'vegetables',
    150,
    'https://images.unsplash.com/photo-1576045057995-568f588f82fb',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Brown Rice',
    'Organic whole grain brown rice',
    5.99,
    'grains',
    200,
    'https://images.unsplash.com/photo-1586201375761-83865001e31c',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Eggs',
    'Farm fresh free-range eggs',
    3.99,
    'dairy',
    100,
    'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Honey',
    'Pure raw honey from local beekeepers',
    8.99,
    'condiments',
    50,
    'https://images.unsplash.com/photo-1587049352846-4a222e784d38',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Organic Potatoes',
    'Fresh organic potatoes, perfect for any dish',
    2.99,
    'vegetables',
    180,
    'https://images.unsplash.com/photo-1518977676601-b53f82aba655',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Fresh Basil',
    'Aromatic fresh basil leaves',
    1.99,
    'herbs',
    100,
    'https://images.unsplash.com/photo-1618164435735-413d3b066c9a',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'Organic Milk',
    'Fresh organic whole milk',
    4.49,
    'dairy',
    80,
    'https://images.unsplash.com/photo-1550583724-b2692b85b150',
    '00000000-0000-0000-0000-000000000001'
  )
ON CONFLICT DO NOTHING;